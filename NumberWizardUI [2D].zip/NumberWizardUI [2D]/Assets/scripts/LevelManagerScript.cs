﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManagerScript : MonoBehaviour {

	public void LoadLevel(string name)
    {
        //Debug.Log("Level load requested for: "+name);
        Application.LoadLevel(name);
    }

    public void QuitLevel()
    {
        //Debug.Log("quit requested");
        Application.Quit();
    }
}
