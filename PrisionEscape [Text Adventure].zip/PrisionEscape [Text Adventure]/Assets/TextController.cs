﻿using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine;

public class TextController : MonoBehaviour {

	public Text text;
	private enum States {cell, mirror, sheets_0, lock_0, cell_mirror, sheets_1, lock_1, corridor_0, corridor_1, corridor_2, corridor_3, stairs_0, stairs_1, stairs_2, floor, closet_door, in_closet, courtyard}; 
	private States myState;

	// Use this for initialization
	void Start () {
		myState = States.cell;
	}
	
	// Update is called once per frame
	void Update () {
		if (myState == States.cell) {
			state_cell ();
		} else if (myState == States.sheets_0) {
			state_sheets_0 ();
		} else if (myState == States.lock_0) {
			state_lock_0 ();
		} else if (myState == States.mirror) {
			state_mirror ();
		} else if (myState == States.sheets_1) {
			state_sheets_1 ();
		} else if (myState == States.lock_1) {
			state_lock_1 ();
		} else if (myState == States.cell_mirror) {
			state_cell_mirror ();
		} else if (myState == States.corridor_0) {
            state_corridor_0();
        } else if (myState == States.corridor_1) {
            state_corridor_1();
        } else if (myState == States.corridor_2) {
            state_corridor_2();
        } else if (myState == States.corridor_3) {
            state_corridor_3();
        } else if (myState == States.stairs_0) {
            state_stairs_0();
        } else if (myState == States.stairs_1) {
            state_stairs_1();
        } else if (myState == States.stairs_2) {
            state_stairs_2();
        } else if (myState == States.floor) {
            state_floor();
        } else if (myState == States.closet_door) {
            state_closet_door();
        } else if (myState == States.in_closet) {
            state_in_closet();
        } else if (myState == States.courtyard) {
            state_courtyard();
        }

    }

    void state_courtyard() {
        text.text = "From the courtyard, you confidently walked outside the prision. You are FREE!\n\n"+"Press P to Play again";
        if (Input.GetKeyDown(KeyCode.P)) {
            myState = States.cell;
        }
    }

    void state_corridor_3()
    {
        text.text = "You wear the outfit of a guard and come out of the closet in the corridor. You can now go through the stairs to the courtyard.\n\n" + "Press S to proceed towards the courtyard ,U to undress return to the closet";
        if (Input.GetKeyDown(KeyCode.S)) {
            myState = States.courtyard;
        }
        else if (Input.GetKeyDown(KeyCode.U)) {
            myState = States.in_closet;
        }
    }

    void state_stairs_2() {
        text.text = "You peek at the stairs. You hear a guard coming towards you. You should immediately escape.\n\n" + "Press R to return to corridor";
        if (Input.GetKeyDown(KeyCode.R)) {
            myState = States.corridor_2;
        }
    }

    void state_corridor_2() {
        text.text = "You are in the corridor again. The only option is to peek at the stairs.\n\n" + "Press S to Peek at the Stairs,B to Return to the closet";
        if (Input.GetKeyDown(KeyCode.B)) {
            myState = States.in_closet;
        } else if (Input.GetKeyDown(KeyCode.S)) {
            myState = States.stairs_2;
        }
    }

    void state_in_closet() {
        text.text = "You carefully pick the closet lock ensuring silence to reach inside the closet. You find a guard dress in the closet.\n\n" + "Press D to dress, R to Return to the corridor";
        if (Input.GetKeyDown(KeyCode.R)) {
            myState = States.corridor_2;
        } else if (Input.GetKeyDown(KeyCode.D)) {
            myState = States.corridor_3;
        }
    }


    void state_stairs_1() {
        text.text = "You can't believe you want to fix the broken stairs with a hairclip. Surely it's time somebody changed them.\n\n" + "Press R to Return to the corridor";
        if(Input.GetKeyDown(KeyCode.R)) {
            myState = States.corridor_1;
        }
    }

    void state_corridor_1() {
        text.text = "You pick up the hairclip but you see the same broken stairs and the closet. The hairclip can be used to pick a lock.\n\n"+ "Press S to View the Stairs, P to Pick the Closet Door";
        if (Input.GetKeyDown(KeyCode.S)) {
            myState = States.stairs_1;
        } else if (Input.GetKeyDown(KeyCode.P)) {
            myState = States.in_closet;
        }
    }

    void state_floor() {
        text.text = "Grace! You found a hairclip on the floor.\n\n" + "Press T to take the hairclip, R to return to the corridor";
        if (Input.GetKeyDown(KeyCode.T)) {
            myState = States.corridor_1;
        } else if (Input.GetKeyDown(KeyCode.T)) {
            myState = States.corridor_0;
        }
    }

    void state_closet_door() {
        text.text = "The closet it locked and you dont have a key with you. But, you see a keyhole in it.\n\n" + "Press R to Return to the corridor";
        if (Input.GetKeyDown(KeyCode.R)) {
            myState = States.corridor_0;
        }
    }

    void state_corridor_0() {
        text.text = "Now you are in a corridor. You can see a broken stair case, the floor and a closet door.\n\n"+ "Press S to View the Stairs, F to View the Floor and C to View the Closet Door";
        if (Input.GetKeyDown(KeyCode.S)) {
            myState = States.stairs_0;
        } else if (Input.GetKeyDown(KeyCode.F)) {
            myState = States.floor;
        } else if (Input.GetKeyDown(KeyCode.C)) {
            myState = States.closet_door;
        }
    }

    void state_stairs_0()
    {
        text.text = "The stairs are too broken and escaping throuh it might alarm the guards.\n\n"+ "Press R to Return to the corridor";
        if (Input.GetKeyDown(KeyCode.R)) {
            myState = States.corridor_0;
        }
    }

    void state_cell() {
		text.text = "You are in a prision cell, and you want to escape. There are some dirty sheets on the bed, a mirror in the wall, and the door is locked from the outside.\n\n"+"Press S to View Sheets, M to View Mirror and L to View Lock";
		if (Input.GetKeyDown (KeyCode.S)) {
			myState = States.sheets_0;
		} else if (Input.GetKeyDown (KeyCode.L)) {
			myState = States.lock_0;
		} else if (Input.GetKeyDown (KeyCode.M)) {
			myState = States.mirror;
		}
	}

	void state_sheets_0() {
		text.text = "You can't believe you sleep in these things. Surely it's time somebody changed them. The pleasure of prision life I guess!\n\n"+"Press R to Return to roaming your cell";
		if (Input.GetKeyDown (KeyCode.R)) {
			myState = States.cell;
		}
	}

	void state_lock_0() {
		text.text = "This is one of those button locks. You have no idea what the combination is. You wish you could somehow see where the dirty fingerprints were, maybe that would help.\n\n"+"Press R to Return to roaming your cell";
		if (Input.GetKeyDown (KeyCode.R)) {
			myState = States.cell;
		}
	}

	void state_mirror() {
		text.text = "The dirty old mirror on the wall seems loose.\n\n"+"Press T to Take the Mirror, or R to Return to cell";
		if (Input.GetKeyDown (KeyCode.T)) {
			myState = States.cell_mirror;
		}else if (Input.GetKeyDown (KeyCode.R)) {
			myState = States.cell;
		}
	}

	void state_sheets_1() {
		text.text = "Holding a mirror in your hand doesn't make the sheets look any better.\n\n"+"Press R to Return to roaming your cell";
		if (Input.GetKeyDown (KeyCode.R)) {
			myState = States.cell_mirror;
		}
	}

	void state_lock_1() {
		text.text = "You carefully put the mirror through the bars, and turn it round so you can see the lock. You can just make out fingerprints around the buttons. You press the dirty buttons, and hear a click.\n\n"+"Press O to Open, or R to Return to roaming your cell";
		if (Input.GetKeyDown (KeyCode.R)) {
			myState = States.cell_mirror;
		} else if (Input.GetKeyDown (KeyCode.O)) {
			myState = States.corridor_0;
		}
	}

	void state_cell_mirror() {
		text.text = "You are still in your cell, and you STILL want to escape! There are some dirty sheets ont the bed, a mark where mirror was, and that pesky door is still there, and firmly locked!\n\n"+"Press S to view Sheets, or L to view Lock";
		if (Input.GetKeyDown (KeyCode.S)) {
			myState = States.sheets_1;
		}else if (Input.GetKeyDown (KeyCode.L)) {
			myState = States.lock_1;
		}
	}
}
